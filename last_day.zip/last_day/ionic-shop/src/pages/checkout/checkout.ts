import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { CartProvider } from '../../providers/cart/cart';

/**
 * Generated class for the CheckoutPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html',
})
export class CheckoutPage {
  cartItems: any[] = [];
  productAmount : number = 0;
  totalAmount : number = 0;
  shippingCharges : number = 10;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private cartService : CartProvider,
    private loadingCtrl : LoadingController) {
      this.loadCartItems();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CheckoutPage');
  }

  loadCartItems() {
    let loader = this.loadingCtrl.create({
      content : 'wait...'
    })
    loader.present();

this.cartService.getCartItems().then(val => {
  this.cartItems = val;

  if(this.cartItems.length > 0) {
    this.cartItems.forEach((prod, indx) => {
      this.productAmount += parseInt(prod.totalPrice);
    });

    this.totalAmount = this.productAmount + this.shippingCharges;
  }
  loader.dismiss();
})

  }

}
