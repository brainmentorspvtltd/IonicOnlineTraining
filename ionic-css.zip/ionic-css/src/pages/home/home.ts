import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { trigger, state, style, transition, animate } from '@angular/animations'
import { AnimationService, AnimationBuilder } from 'css-animator'

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  animations : [
    trigger('myVisibility', [
      state('visible', style({
        opacity : 1
      })),
      state('invisible', style({
        opacity: 0
      })),
      transition('* => *', animate('1s'))
    ])
  ]
})
export class HomePage {
  splash = true;
  tabBarElem : any;
  visibleState = 'visible';

  @ViewChild('myElement') myElem;
  private animator : AnimationBuilder;

  constructor(public navCtrl: NavController, animationService : AnimationService) {
    this.tabBarElem = document.querySelector('.tabbar');
    this.animator = animationService.builder()
  }

  animateElem() {
    this.animator.setType('flipInX').show(this.myElem.nativeElement);
  }

  // If you are not using tabs template
  // ionViewDidLoad() {
  //   setTimeout(() => this.splash = false, 4000);
  // }

  ionViewDidLoad() {
    this.tabBarElem.style.display = 'none';
    setTimeout(() => {
      this.splash = false;
      this.tabBarElem.style.display = 'flex';
    }, 4000);
  }

  toggleVisible() {
    this.visibleState = (this.visibleState == 'visible') ? 'invisible' : 'visible';
  }

}
