import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  splash = true;
  tabBarElem : any;

  constructor(public navCtrl: NavController) {
    this.tabBarElem = document.querySelector('.tabbar');
  }

  // If you are not using tabs template
  // ionViewDidLoad() {
  //   setTimeout(() => this.splash = false, 4000);
  // }

  ionViewDidLoad() {
    this.tabBarElem.style.display = 'none';
    setTimeout(() => {
      this.splash = false;
      this.tabBarElem.style.display = 'flex';
    }, 4000);
  }

}
