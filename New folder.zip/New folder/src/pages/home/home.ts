import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Events } from 'ionic-angular';
import { ProductsProvider } from '../../providers/products/products';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  promoSliders : any[];
  promoImagesLoaded : boolean = false;
  productRows : any;
  products : any[];

  constructor(public navCtrl: NavController, public navParams : NavParams,
    private productService : ProductsProvider,
    private ctrl : LoadingController,
    private event : Events
    ) {

  }

  ionViewWillEnter() {
    this.loadPromo();
    this.loadProducts();
  }

  ionViewDidLeave() {
    this.event.unsubscribe('promoLoaded');
  }

  loadPromo() {
    // let loader = this.ctrl.create({
    //   content : 'Loading Promotions...'
    // });
    // loader.present();
    this.productService.getPromoSlider();
    this.event.subscribe('promoLoaded', () => {
      
      this.promoSliders = this.productService.promos;
      console.log(this.promoSliders);
      if(this.promoSliders.length > 0) {
        this.promoImagesLoaded = true;
      }
      // loader.dismiss();
    })
  }

  loadProducts(){
    this.productService.getProducts();
    this.event.subscribe('productsLoaded', () => {
      this.products = this.productService.products;
      this.productRows = Array.from(Array(Math.ceil(this.products.length / 2)).keys());
      console.log(this.products, this.productRows);
    })
  }

}
