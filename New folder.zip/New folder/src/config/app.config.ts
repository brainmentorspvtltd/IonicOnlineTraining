
  // Initialize Firebase
  export const config = {
    showCategory : true,
    firebaseConfig : {
      apiKey: "AIzaSyC5WsfZoJ4yYvgFEY4kTtDYU4hEXdkereU",
      authDomain: "ionic-firebase-shop.firebaseapp.com",
      databaseURL: "https://ionic-firebase-shop.firebaseio.com",
      projectId: "ionic-firebase-shop",
      storageBucket: "ionic-firebase-shop.appspot.com",
      messagingSenderId: "1031934582565"
    }
  };