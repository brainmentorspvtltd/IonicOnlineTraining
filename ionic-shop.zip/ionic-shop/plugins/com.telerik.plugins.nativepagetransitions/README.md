## Native Page Transitions Cordova / PhoneGap Plugin
by [Telerik](http://www.telerik.com)


<table width="100%">
    <tr>
        <td width="100"><a href="http://plugins.telerik.com/plugin/native-page-transitions"><img src="http://www.x-services.nl/github-images/telerik-verified-plugins-marketplace.png" width="97px" height="71px" alt="Marketplace logo"/></a></td>
        <td>For a quick demo app and easy code samples, check out the plugin page at the Verified Plugins Marketplace: http://plugins.telerik.com/plugin/native-page-transitions</td>
    </tr>
</table>


Using the Cordova CLI?

```
cordova plugin add com.telerik.plugins.nativepagetransitions
```

Using PGB?

```xml
<plugin name="com.telerik.plugins.nativepagetransitions" source="npm" />
```

[The MIT License (MIT)](http://www.opensource.org/licenses/mit-license.html)
