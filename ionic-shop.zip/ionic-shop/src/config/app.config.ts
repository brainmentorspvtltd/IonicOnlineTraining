
  // Initialize Firebase
  // export const config = {
  //   showCategory : true,
  //   firebaseConfig : {
  //     apiKey: "AIzaSyC5WsfZoJ4yYvgFEY4kTtDYU4hEXdkereU",
  //     authDomain: "ionic-firebase-shop.firebaseapp.com",
  //     databaseURL: "https://ionic-firebase-shop.firebaseio.com",
  //     projectId: "ionic-firebase-shop",
  //     storageBucket: "ionic-firebase-shop.appspot.com",
  //     messagingSenderId: "1031934582565"
  //   }
  // };

  export const config = {
    showCategory : true,
    firebaseConfig: {
      apiKey: "AIzaSyCW7hwYvB3b1qpR6VLNb-eGOhXklP-oAuU",
      authDomain: "ionic-firebase-cart.firebaseapp.com",
      databaseURL: "https://ionic-firebase-cart.firebaseio.com",
      projectId: "ionic-firebase-cart",
      storageBucket: "ionic-firebase-cart.appspot.com",
      messagingSenderId: "539859030675"
 }
  };