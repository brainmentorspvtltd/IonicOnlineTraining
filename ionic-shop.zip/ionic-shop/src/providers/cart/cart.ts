import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

const CART_KEY = 'cartItem';

/*
  Generated class for the CartProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class CartProvider {

  constructor(public http: HttpClient, public storage : Storage) {
    console.log('Hello CartProvider Provider');
  }

  addToCart(product) {
    return this.getCartItems().then(result => {
      if(result) {
        if(! this.containsObject(product, result)) {
          result.push(product);
          return this.storage.set(CART_KEY, result);
        } else {
          let index = result.findIndex(x => x.product_id == product.product_id);
          let quantity = parseInt(result[index].count);
          product.count = (quantity + product.count);
          let currentPrice = parseInt(product.totalPrice) * product.count;
          product.totalPrice = currentPrice;
          return this.storage.set(CART_KEY, result);
        }
      }
      else {
        return this.storage.set(CART_KEY, [product]);
      }
    })
  }

  containsObject(obj, list) : boolean {
    if (!list.length) {
      return false;
    }
    if (obj == null) {
      return false;
    }
    var i;
    for(i = 0; i < list.length; i++) {
      if(list[i].product_id == obj.product_id) {
        return true;
      }
    }
    return false;
  }

  getCartItems() {
    return this.storage.get(CART_KEY);
  }

}
