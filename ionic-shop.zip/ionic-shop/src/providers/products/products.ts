import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Events } from 'ionic-angular';
import firebase from 'firebase';

/*
  Generated class for the ProductsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ProductsProvider {

  
  promoRef = firebase.database().ref("/promotions");
  promos : Array<any> = [];

  productsRef = firebase.database().ref("products");
  products:Array<any> = [];

  constructor(public http: HttpClient, public event : Events) {
    // console.log('Hello ProductsProvider Provider');
  }

  getPromoSlider() {
    // console.log("PR ",this.promoRef);
    this.promoRef.on('value', (snap) => {
      console.log("Snapshot",snap);
      this.promos = [];
      if (snap.val()) {
        var tempPromo = snap.val();
        console.log(tempPromo);
        for(var key in tempPromo) {
          let singlePromo = {
            id : key, 
            name : tempPromo[key].thumb
          };
          this.promos.push(singlePromo);
        }
      }
      this.event.publish('promoLoaded');
    })
  }

  getProducts() {
    this.productsRef.once('value', (snap) => {
      this.products = [];
      if(snap.val()) {
        var tempProducts = snap.val();
        for(var key in tempProducts) {
          let singleProduct = {
            id : key,
            category_id : tempProducts[key].category_id,
            name : tempProducts[key].name,
            images : tempProducts[key].images,
            price : tempProducts[key].price,
            rating : tempProducts[key].rating,
            sale_price : tempProducts[key].sale_price,
            short_desc : tempProducts[key].short_description,
            thumb : tempProducts[key].thumb
          };
          this.products.push(singleProduct);
        }
      }

      this.event.publish('productsLoaded');

    })
  }

}