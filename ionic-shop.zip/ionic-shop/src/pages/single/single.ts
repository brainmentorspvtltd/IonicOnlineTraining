import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the SinglePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-single',
  templateUrl: 'single.html',
})
export class SinglePage {

  selectedProduct : any;
  productCount : number = 1;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    if(this.navParams.get("product")) {
      window.localStorage.setItem('selectedProduct', JSON.stringify(this.navParams.get("product")))
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SinglePage');
  }

  ionViewDidEnter() {
    this.getSingleProduct();
  }

  getSingleProduct() {
    if(window.localStorage.getItem("selectedProduct") != 'undefined') {
      this.selectedProduct = JSON.parse(window.localStorage.getItem('selectedProduct'));
      console.log(this.selectedProduct);
    }
  }

  decreaseCount() {
    if(this.productCount > 1) {
      this.productCount--;
    }
  }

  increaseCount() { 
    this.productCount++;
  }

}
