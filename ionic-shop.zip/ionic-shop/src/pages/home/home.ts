import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, Events } from 'ionic-angular';
import { ProductsProvider } from '../../providers/products/products';
import { NativeTransitionOptions, NativePageTransitions } from '@ionic-native/native-page-transitions';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  promoSliders : any[];
  promoImagesLoaded : boolean = false;
  productRows : any;
  products : any[];

  constructor(public navCtrl: NavController, public navParams : NavParams,
    private productService : ProductsProvider,
    private ctrl : LoadingController,
    private event : Events,
    private nativePageTransition : NativePageTransitions
    ) {

  }

  ionViewWillEnter() {
    this.loadPromo();
    this.loadProducts();
  }

  ionViewDidLeave() {
    this.event.unsubscribe('promoLoaded');
  }

  loadPromo() {
    let loader = this.ctrl.create({
      content : 'Loading Promotions...'
    });
    loader.present();
    this.productService.getPromoSlider();
    this.event.subscribe('promoLoaded', () => {
      
      this.promoSliders = this.productService.promos;
      // console.log(this.promoSliders);
      if(this.promoSliders.length > 0) {
        this.promoImagesLoaded = true;
        // console.log(this.promoSliders);
      }
      loader.dismiss();
    })
  }

  loadProducts(){
    this.productService.getProducts();
    this.event.subscribe('productsLoaded', () => {
      this.products = this.productService.products;
      this.productRows = Array.from(Array(Math.ceil(this.products.length / 2)).keys());
      console.log(this.products, this.productRows);
    })
  }

  singleProduct(product) {
    // console.log("Single Product Page");
    let options : NativeTransitionOptions = {
      direction : 'up',
      duration : 1000,
      slowdownfactor : 3,
      slidePixels : 20,
      iosdelay:100,
      androiddelay : 100,
      fixedPixelsTop : 0,
      fixedPixelsBottom : 50
    }
    this.nativePageTransition.slide(options);
    this.navCtrl.push("SinglePage", {product : product})
  }

  cartPage() {
    this.navCtrl.push("CartPage")
  }

}
