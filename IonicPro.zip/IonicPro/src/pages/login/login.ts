import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import {HomePage} from '../home/home';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  @ViewChild('username') uname;
  @ViewChild('password') upwd;

  constructor(public navCtrl: NavController, public navParams: NavParams, public alertCtrl:AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  loginUser() {
    // console.log(this.uname.value, this.upwd.value);
    if(this.uname.value == 'Ravi' && this.upwd.value == 'ravi') {
      const alert = this.alertCtrl.create({
        title: 'Login Success',
        subTitle: 'LoggedIn Successfully',
        buttons: ['OK']
      });
      alert.present();
      this.navCtrl.push(HomePage);
    }
  }

}
