import { Injectable } from '@angular/core';
import {environment} from '../environments/environment';
import { HttpClient } from '@angular/common/http';

const API_URL = environment.apiUrl;
const API_KEY = environment.apiKey;

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  currentArticle : any;

  constructor(private http : HttpClient) { }

  getData(url) {
    // console.log(API_URL+url+'&apiKey='+API_KEY);
    return this.http.get(API_URL+url+'&apiKey='+API_KEY);
    // https://newsapi.org/v2/everything?q=bitcoin&from=2018-11-12&sortBy=publishedAt&apiKey=695e07af402f4b119f0703e9b19f4683
  }
}
